fetch('https://example.com');
const xhr = new XMLHttpRequest();
const x = Math.random();
const y = new Date();
